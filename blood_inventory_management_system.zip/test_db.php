<?php
include("db.php");
echo "Database connected successfully!";
?>
